function attachEvents() {
    const username = 'guest';
    const password = 'pass';
    const appId = 'kid_BJ_Ke8hZg';
    const authHeaders = {Authorization: `Basic ${btoa(username + ':' + password)}`}
    const baseUrl = `https://baas.kinvey.com/appdata/${appId}/venues/`;
    const baseUrlrpc = `https://baas.kinvey.com/rpc/${appId}/custom/calendar`;
    const loginUrl = `https://baas.kinvey.com/user/${appId}/login`;

    let sessionToken = null;
    $.post({
        url: loginUrl,
        headers: authHeaders,
        data: JSON.stringify({
            "username":username,
            "password":password
        })
    })
        .then((data) => sessionToken = data._kmd.authtoken)
        .catch(renderError);

    function renderError(error) {
        console.dir(error);
    }

}